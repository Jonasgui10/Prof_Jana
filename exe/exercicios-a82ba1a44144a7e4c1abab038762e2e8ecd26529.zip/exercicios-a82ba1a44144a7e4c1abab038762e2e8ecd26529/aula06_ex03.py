# Exercício 3 - Aula 6

num = int(input('Digite um número: '))

if num%2 == 0:
    print('O número {} é par.'.format(num))
else:
    print('O número {} é impar.'.format(num))