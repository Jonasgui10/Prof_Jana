# Exercicio 3 - aula 2
um=int(input('Digite o primeiro número: '))
dois=int(input('Digite o segundo número: '))
soma=um+dois
print('A soma de {} e {} é igual a {}'.format(um,dois,soma))
