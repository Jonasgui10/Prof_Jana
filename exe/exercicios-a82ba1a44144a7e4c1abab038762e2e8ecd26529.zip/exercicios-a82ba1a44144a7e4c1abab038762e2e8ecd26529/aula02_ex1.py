# Exercício 1 - Aula 2
nome=input('Qual seu nome?')
print('Olá', nome, 'bem-vindo ao python!')
