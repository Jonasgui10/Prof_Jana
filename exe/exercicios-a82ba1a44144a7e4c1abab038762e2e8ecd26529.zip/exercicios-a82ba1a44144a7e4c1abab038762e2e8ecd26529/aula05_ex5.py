# Exercício 5 - Aula 5

num = input('Digite um número: ')
u=num[3]
d=num[2]
c=num[1]
m=num[0]

print('Analisando o número {} podemos identificar a unidade {}, a dezena {}, a centena {} e o milhar {} '.format(num,u,d,c,m))
