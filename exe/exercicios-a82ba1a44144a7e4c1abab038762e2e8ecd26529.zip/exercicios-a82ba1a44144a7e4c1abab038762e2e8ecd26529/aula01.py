nome=input('Qual o seu nome?')
idade=input('Quantos anos você têm?')
altura=input('Qual sua altura?')
print(nome,idade,altura)
