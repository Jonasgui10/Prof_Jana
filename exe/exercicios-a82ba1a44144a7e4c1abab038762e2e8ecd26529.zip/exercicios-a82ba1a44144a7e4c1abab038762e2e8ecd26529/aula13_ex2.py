# Exercício 2 - Aula 13

for n in range(2,50):
    print(n)
print('Acabou!')