# Exemplo de validações de variável
# Comentário de várias linhas de código usando os ''' '''

'''a=input('Digite algo: ')

print('O tipo primitivo desse valor é: ', type(a))
print('Só tem espaços ', a.isspace())
print('É um numero ', a.isnumeric())
print('É alfabético ', a.isalpha())
print('É alfanumérica', a.isalnum())
print('Esta em maiuscula ', a.isupper())
print('Esta em minuscula ', a.islower())
print('Está capitalizada', a.istitle())'''

a=input('Digite algo: ')

print('O tipo primitivo desse valor é: ', type(a))