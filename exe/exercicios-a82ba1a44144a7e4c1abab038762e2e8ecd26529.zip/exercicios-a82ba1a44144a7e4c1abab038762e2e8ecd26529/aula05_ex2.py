# Exercício 2 - Aula 5

from math import hypot2


co=float(input('Comprimento do cateto oposto: '))
ca = float(input('Comprimento do cateto adjacente: '))
hi = hypot(co,ca)

print('A hipotenusa vai medir {:.2f}.'.format(hi))