# Exercício 3 - Aula 3
deslocamento=float(input('Digite o deslocamento em metros: '))
tempo=float(input('Digite o tempo em segundos:'))
velocidade=deslocamento/tempo
print('A velocidade média é igual a {:.2f} m/s'.format(velocidade))
