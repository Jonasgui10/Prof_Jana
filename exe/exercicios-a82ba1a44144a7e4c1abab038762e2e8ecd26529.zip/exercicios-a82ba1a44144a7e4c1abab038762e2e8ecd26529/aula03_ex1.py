num=int(input('Digite um número: '))
ant=num-1
suc=num+1
print('Analisando o valor {}, seu antecessor é {} e o seu sucessor é {}'.format(num,ant,suc))
