# Exercício 2 - Aula 12

nome=input('Qual seu nome completo: ').strip()
print('Seu nome têm DIAS? {} '.format('DIAS' in nome.upper()))