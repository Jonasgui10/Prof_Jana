# Exercício 0 - Aula 2

nota1=float(input('Digite a nota 1: '))
nota2=float(input('Digite a nota 2: '))

media=(nota1+nota2)/2

print('A média aritmética do aluno é ', media)