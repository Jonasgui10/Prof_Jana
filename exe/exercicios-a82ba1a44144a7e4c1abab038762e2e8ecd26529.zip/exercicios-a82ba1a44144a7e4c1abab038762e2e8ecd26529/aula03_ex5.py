# Exercício 5 - Aula 3
pi=float(3.14)
raio=float(input('Digite o raio da área de convivência: '))
area=pi*(raio**2)
print('Àrea igual a {:.2f}.'.format(area))
