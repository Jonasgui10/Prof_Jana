# Exercício 1 - Aula 5

from math import trunc

num = float(input('Digite um valor: '))
inteira = trunc(num)
print('O valor digitado foi {} e a sua porção inteira é {}.'.format(num,inteira))