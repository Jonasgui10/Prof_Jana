# Exercício 1 - Aula 13

from time import sleep

for cont in range(10, -1, -1):
    sleep(1)
    print(cont)
print('BUM!!')
