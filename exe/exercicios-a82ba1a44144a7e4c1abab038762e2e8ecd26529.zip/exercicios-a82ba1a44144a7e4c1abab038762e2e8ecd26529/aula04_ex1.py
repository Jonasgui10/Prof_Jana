# Exercício 1 - Aula 4
base=float(input('Base do triangulo (cm):'))
alt = float(input('Alutra do triangulo (cm)'))
area = (base*alt)/2
print('Àrea igual a {:.2f} cm9².'.format(area))