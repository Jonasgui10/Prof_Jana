# Exercício 4 - Aula 3
preco=float(input('Qual o valor do produto:'))
quantidade=float(input('Qual a quantidade de produtos vendidos: '))
comissao=(preco*quantidade)*0.05
print('Comissão é igual a: {:.2f}.'.format(comissao))
