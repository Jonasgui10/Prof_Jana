# Exercício 3 - Aula 4

a = float(input('Digite o valor de a: '))
b = float(input('Digite o valor de b: '))
c = float(input('Digite o valor de c: '))

delta = b**2 - 4*a*c

print('Delta é igual à {:.2f}'.format(delta))