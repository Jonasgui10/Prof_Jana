nota1 = int(input('Informe a nota 1: '))
nota2 = int(input('Informe a nota 2: '))
media=(nota1+nota2)/2

if media>=6:
    print('Aprovado')
else:
    print('Reprovado')