# Exercício 2 - Aula 3

n=int(input('Digite um número: '))
d=n*2
t=n*3
r=n**(1/2)
print('O dobro de {} vale {}. \n O triplo de {} vale {}. \n A raiz quadrada de {} é igual a {}.'.format(n,d,n,t,n,r))
