# Exercicio 5 - Aula 2
altura=float(input('Digite a sua altura em metros: '))
altura= altura*100
print('Sua altura é de {} cm.'.format(altura))
