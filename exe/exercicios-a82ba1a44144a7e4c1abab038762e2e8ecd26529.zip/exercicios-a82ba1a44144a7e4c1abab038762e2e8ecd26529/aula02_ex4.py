# Exercicio 4 - Aula 2
distancia=float(input('Digite a distância percorrida do automóvel: '))
combustivel=float(input('Digite o total de combustível gasto:'))
km_litro=distancia/combustivel
print('O automóvel consome {:.2f} km/l'.format(km_litro))
