# Exercicio 2 - Aula 2
dia=input('Qual seu dia de nascimento?')
mes=input('Qual seu mês de nascimento?')
ano=input('Qual seu ano de nascimento?')
print('Você nasceu no dia ', dia, 'de', mes, 'de', ano)
print('Você nasceu no dia {} de {} de {}'.format(dia, mes, ano))
