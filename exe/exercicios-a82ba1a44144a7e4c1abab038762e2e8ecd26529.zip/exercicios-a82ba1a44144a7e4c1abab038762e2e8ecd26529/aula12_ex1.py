# Exercício 1 - Aula 12

cidade=input('Em que cidade você nasceu? ').strip()

print(cidade[:5].upper()== 'SANTA')